<?php
// DIT IS DE HOMEPAGINA
session_start();

if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {

    require_once('../db_conn.php');




    if (isset($_POST['submit'])) {
        if (empty($_POST['title'])  || empty($_POST['description'])) {


            
            echo 'Please Fill in the blanks';
        } else {
            $ProductTitle = $_POST['title'];
            $ProductImage = $_POST['image'];
            $ProductDescription = $_POST['description'];

            // image file directory
            $query = " INSERT INTO `products` (title , image, description) VALUES('$ProductTitle', '$ProductImage', '$ProductDescription') ";
            $result = mysqli_query($conn, $query);

            if ($result) {
                header("location:view.php");
            } else {
                echo " check your query ";
            }
        }
    } else {
        header("location: index.php");
    }
} else {
    mysqli_close($conn);
    header("Location: .../index.php");
    exit();
}
