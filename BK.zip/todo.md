<!--

http://localhost/%5bSchoolwerk%20ALLE%20VAKKEN%5d/Periode%203/PHP/

 -->
Insert is working




zorgen dat de redirects werken als je niet ingelogd bent✔️

producten toevoegen en verwijderen uit de database!!!!!!!!!!!

Registreermogelijkheid
Nog werken aan de admin page zodat alle users kunnen beheerd worden vanaf een pagina✔️

if{
    Julian of ... is ingelogd. SHow admin page button!
} else {
    dont show admin button
}

Handy Links:
php Advanced Shopping Cart Tutorial With Php and MySqli Database:
https://youtu.be/eAK8uYtNTy4


https://youtu.be/SlF1VNXHD1o
How to Insert Update Delete In Php Mysqli

Datatable server side processing CRUD Operations , Bootstrap 5 , PHP MYSQL AJAX
https://youtu.be/oxWv74OI6xA
